import pandas as pd

area = pd.Series({
    "Bangalore": 709,
    "Delhi": 1484,
    "Chennai": 426,
    "Mumbai": 603
})

population = pd.Series({
    "Bangalore": 8.4,
    "Delhi": 19.0,
    "Chennai": 7.1,
    "Mumbai": 20.4
})

df = pd.DataFrame({
    "area": area,
    "population": population
})

df["density"] = df["population"] / df["area"]

print("DataFrame:\n", df)

print("\nUsing loc:")
print(df.loc[["Delhi", "Chennai"], ["population", "density"]])

print("\nUsing iloc:")
print(df.iloc[[1, 2], [1, 2]])

print("\nUsing ix:")
print(df.loc[["Delhi", "Chennai"], ["population", "density"]])

print("\nCities with density > 2:")
print(df[df["density"] > 2].index.tolist())